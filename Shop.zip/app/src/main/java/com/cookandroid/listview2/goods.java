package com.cookandroid.listview2;

public class goods {
    private int image_id; // 이미지
    private String title; // 물건명
    private int price; // 금액
    public goods(int image_id, String title, int price){
        this.image_id = image_id;
        this.title=title;
        this.price = price;
    }
    public void setImage_id(int image_id) { this.image_id = image_id; }
    public void setTitle(String title) { this.title = title; }
    public void setPrice(int price) { this.price = price; }
    public int getImage_id() { return image_id; }
    public String getTitle() { return title; }
    public int getPrice() { return price; }
}