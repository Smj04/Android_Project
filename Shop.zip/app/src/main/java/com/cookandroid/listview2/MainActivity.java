package com.cookandroid.listview2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView1;
    goodsAdapter mAdapter;
    ArrayList<goods> mArray;
    goods mItem;

    Integer[] imgList = { R.drawable.avocado, R.drawable.bean_sprouts,R.drawable.chicken_breast, R.drawable.coffee,
            R.drawable.egg, R.drawable.mushroom, R.drawable.peach, R.drawable.photato, R.drawable.shine_musket };
    String[] titles = { "아보카도", "콩나물", "닭가슴살","맥심커피100", "달걀", "버섯", "복숭아", "감자", "샤인머스켓" };
    int[] prices = { 3000,1200, 2000, 12000, 5000, 2000, 10000, 4500, 15000};
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemBasket:
                Intent in = new Intent(getApplicationContext(),BasketList.class);
                startActivity(in); return true;
            case R.id.itemExit:
                finish(); return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView1=(ListView)findViewById(R.id.list);
        mArray = new ArrayList<goods>();
        for(int i=0; i<imgList.length; i++){
            mItem = new goods(imgList[i], titles[i], prices[i]);
            mArray.add(mItem);
        }
        mAdapter=new goodsAdapter(this, mArray);
        listView1.setAdapter(mAdapter);
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                goods clickItem = (goods) listView1.getItemAtPosition(arg2);
                Intent in = new Intent(getApplicationContext(),ItemView.class);
                in.putExtra("img_id", clickItem.getImage_id());
                in.putExtra("title", clickItem.getTitle());
                in.putExtra("price", clickItem.getPrice());
                startActivity(in);
            }
        });
    }
}
