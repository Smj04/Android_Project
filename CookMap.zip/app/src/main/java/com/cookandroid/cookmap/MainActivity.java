package com.cookandroid.cookmap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("2108 서민정[구글맵 실습]");
        setContentView(R.layout.activity_main);
    }
}
