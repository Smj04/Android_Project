package com.cookandroid.bank_table;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class BankOutput extends Fragment {
    Button btnOutputOk;
    EditText edtOutput; TextView txtResult;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.bank_output, container,false);
        edtOutput = v.findViewById(R.id.edtOutput);
        btnOutputOk = v.findViewById(R.id.btnOutputOk);
        txtResult = v.findViewById(R.id.txtResult);
        btnOutputOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n = Integer.parseInt(edtOutput.getText().toString()); BankValue.data -= n;
                txtResult.setText(n+"원 출금\n잔액은"+BankValue.data+"입니다."); edtOutput.setText("0");
            }
        });
return v;
    }
}
