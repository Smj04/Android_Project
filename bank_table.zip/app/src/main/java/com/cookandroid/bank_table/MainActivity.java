package com.cookandroid.bank_table;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    TabLayout tabLay;
    ViewPager viewPager;
    FragmentAdapter fragAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabLay = findViewById(R.id.tabLay);
        viewPager = findViewById(R.id.viewPager);
        fragAdapter = new FragmentAdapter(getSupportFragmentManager());
        viewPager.setAdapter(fragAdapter);
        tabLay.setupWithViewPager(viewPager);
        tabLay.getTabAt(0).setText("잔액");
        tabLay.getTabAt(1).setText("입금");
        tabLay.getTabAt(2).setText("출금");
        tabLay.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()){
                    case 0:
                        Toast.makeText(getApplicationContext(), "잔액확인", Toast.LENGTH_LONG).show(); break;
                    case 1:
                        Toast.makeText(getApplicationContext(), "입금을 합니다.", Toast.LENGTH_LONG).show(); break;
                    case 2:
                        Toast.makeText(getApplicationContext(), "출금을 합니다.", Toast.LENGTH_LONG).show(); break;

                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
}
