package com.cookandroid.bank_table;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class BankInput extends Fragment {
    Button btnInputOk;
    EditText edtInput; TextView txtResult;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.bank_input, container,false);
        edtInput = v.findViewById(R.id.editInput);  btnInputOk = v.findViewById(R.id.btnInputOk);
        txtResult = v.findViewById(R.id.txtResult); txtResult.setText("");
        btnInputOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n = Integer.parseInt(edtInput.getText().toString()); BankValue.data+=n;
                txtResult.setText(n+"원 입금\n잔액은 "+BankValue.data+"입니다.");    edtInput.setText("0");
            }
        });
        return v;
    }
}
