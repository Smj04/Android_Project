package com.cookandroid.bank_table;

public class BankValue {
    public static int data = 10000;
}
