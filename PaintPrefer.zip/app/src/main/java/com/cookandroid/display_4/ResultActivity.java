package com.cookandroid.display_4;

import android.content.Intent;
import android.media.Rating;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);

        Intent in = getIntent();
        int[] voteResult = in.getIntArrayExtra("VoteCount");
        String[] ImageName = in.getStringArrayExtra("ImageName");

        TextView tv[] = new TextView[ImageName.length];
        RatingBar rbar[] = new RatingBar[ImageName.length];

        Integer tvID[] = {R.id.tv1, R.id.tv2, R.id.tv3, R.id.tv4, R.id.tv5, R.id.tv6, R.id.tv7, R.id.tv8,
                R.id.tv9};
        Integer rbarID[] = {R.id.rbar1, R.id.rbar2, R.id.rbar3, R.id.rbar4, R.id.rbar5, R.id.rbar6,
                R.id.rbar7,
                R.id.rbar8, R.id.rbar9};

        for(int i = 0; i< voteResult.length; i++){
            tv[i] = findViewById(tvID[i]);
            rbar[i] = findViewById(rbarID[i]);
        }

        for(int i= 0; i<voteResult.length; i++){
            tv[i].setText(ImageName[i]);
            rbar[i].setRating(voteResult[i]);
        }
        Button btnReturn = findViewById(R.id.btnReturn);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
